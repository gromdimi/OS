#include "lab03.h"

int main() {
    print_message();
    print_message();
    return 0;
}
